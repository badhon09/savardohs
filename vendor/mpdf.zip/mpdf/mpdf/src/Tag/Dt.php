<?php

namespace Mpdf\Tag;

class Dt extends BlockTag
{


}
