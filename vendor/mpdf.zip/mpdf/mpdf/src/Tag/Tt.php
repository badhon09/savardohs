<?php

namespace Mpdf\Tag;

class Tt extends InlineTag
{


}
